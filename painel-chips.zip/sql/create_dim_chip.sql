CREATE TABLE `painel-universidade.marts.dim_chip`(
id_chip INT64, numero STRING, operadora STRING, situacao STRING, data_update TIMESTAMP);