CREATE TABLE `painel-universidade.marts.f_chip_aparelho`(
id_relacao STRING, id_chip INT64, id_aparelho INT64, operador STRING, status STRING);